define(
    ['field/object', "checkers/model", "utils/state", "underscore"],
    function (field, collection, state, _) {

        function takeChecker(x1, y1, x2,y2){
            
            var x = (x1+x2)/2;
            var y = (y1+y2)/2;
            
            var model = collection.checkPosition(x, y);
            model[0].set({taken:true});
            
            var restOfColor = collection.where({'taken':false, 'color':  model[0].get('color')});
            
            if(restOfColor.length === 0){
                alert(model[0].get('color')+ ' LOST');
            }
            
        }
        
        function moveChecker(x, y) {
            if (state.get('status') === 'in_move') {

                var cur_pos = state.get('cur_checker_pos');
                var direction = state.get('cur_checker_direction');
                var number = state.get('cur_checker_number');

                var model = collection.at(number);
                
                var free_cells = getPosibleCellsFromPos(cur_pos[0], cur_pos[1], direction, model.get('color'));
 
                var flag = false;
                for (var i in free_cells) {
                    var free_cell = free_cells[i];
                    if (free_cell[0] === x && free_cell[1] === y) {
                        flag = true;
                        break;
                    }
                }
                var oldX = model.get('x');
                var oldY = model.get('y');

                if (flag) {

                    model.set({
                        'x': x,
                        'y': y
                    });
                    
                    if(field.calc.getCellDistance(oldX,oldY, x,y)> 2){
                        
                        takeChecker(oldX,oldY, x,y);
                        
                        return getPosibleCellsFromPos(x, y, model.get('direction'), model.get('color'));
                        
                        return false;
                    }
                    
                    return true;
                } else {

                }
                
                return false;

                //state.set('status', 'after_move');
                //console.log('move checker', direction, x, y, free_cells);

            }
        }
        
        function filterFreeCells(cells, returnOcupied) {
            returnOcupied = returnOcupied || false;
            var busy_cells = [];
            var free_cells = [];

            for (var k in cells) {
                var position = cells[k];
                var model = collection.checkPosition(position[0], position[1]);
                
                if (model[0] === undefined) {
                    free_cells.push(position);
                }
                if (returnOcupied) {
                    if (model[0] !== undefined) {

                        busy_cells.push({
                            pos: position,
                            color: model[0].get['color']
                        });
                    }
                }
            }

            if (!returnOcupied) {
                return free_cells;
            }
            return {
                free: free_cells,
                busy: busy_cells
            };
        };

        function getPosibleCellsFromPos(x, y, direction, color, free) {

            var empty_free_flag =  false;
            
            if(free === undefined){
                empty_free_flag = true;
            }
            free = free || [[x,y]];
            
            
            var cells = field.calc.getShortDirection(x, y, direction);

            var posible_cells = filterFreeCells(cells, true);
            
            if(direction !== 0){
                free = posible_cells['free'];
            }
            var busy = posible_cells['busy'];
            
            if (busy.length > 0) {
                for (var b in busy) {
                    var b_cell = busy[b];

                    var cell_checker = collection.checkPosition(b_cell['pos'][0], b_cell['pos'][1]);
                    var b_color = cell_checker[0].get('color');
                    
                    
                    if (b_color !== color) {

                        var dx = b_cell['pos'][0] - x;
                        var newX = b_cell['pos'][0] + dx;

                        var dy = b_cell['pos'][1] - y;
                        var newY = b_cell['pos'][1] + dy;

                        if (field.calc.isValid(newX, newY)) {

                            
                            var new_cell = collection.checkPosition(newX, newY);
                            
                            
                            if (new_cell.length === 0) {
                                var isFree = _.find(free, function(arr){ return (arr[0]===newX && arr[1]===newY);})
                                
                                if(isFree === undefined){
                                    free.push([newX, newY]);
                                    //free = getPosibleCellsFromPos(newX, newY, 0, color, free);
                                }
                                
                            }
                        }

                        //console.log('b_cell',b_cell, tmp);
                    }

                }
            }

            if( empty_free_flag){
                free = _.filter(free, function(arr){
                    return !(arr[0] === x && arr[1] === y);
                });
            }
            
            
            return free;

        };
        
        
        var that = {
            filterFreeCells: filterFreeCells,
            moveChecker:moveChecker,
            getPosibleCellsFromPos: getPosibleCellsFromPos,
        };
        
        return that;
    });