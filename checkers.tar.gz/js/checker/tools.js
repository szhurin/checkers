define(
    ['field/object', "checkers/model", "utils/state", "./moves",  "underscore"],
    function (field, collection, state, moves, _) {

        
        function uncheckCeckers(){
            $('._checker').removeClass('_checker_selected');
            state.set('cur_checker_pos', false);
            state.set('cur_checker_direction', false);
            state.set('cur_checker_number', false);
            state.set('status', 'wait_select');
                
        };
        
        function regCheckerAction() {
            $('._checker').click(function () {
                var color = $(this).attr('color');

                if (state.get('move_color') !== color) {
                    return;
                }

                state.set('move_color', color);
                state.set('status', 'in_move');

                $('._checker').removeClass('_checker_selected');
                $(this).addClass('_checker_selected');

                var number = $(this).attr('number') - 0;
                var direction = $(this).attr('direction') - 0;

                var model = collection.at(number);

                var x = model.get('x');
                var y = model.get('y');

                state.set('cur_checker_pos', [x, y]);
                state.set('cur_checker_direction', direction);
                state.set('cur_checker_number', number);

                var free_cells = moves.getPosibleCellsFromPos(x, y, model.get('direction'), model.get('color'));
                
                //console.log(free_cells);
                
                $('.' + field.field_cell_class).removeClass('_red_cell');
                for (var i in free_cells) {
                    var cell = free_cells[i];
                    $('#' + field.draw.getCellIDPart + field.calc.getPosition(cell[0], cell[1])).addClass('_red_cell');
                }

            });

            $('.' + field.field_cell_class).click(function (e) {
                
                if(e.target !== e.currentTarget){
                    return;
                }
                var pos = field.getCellPos(this);
                
                var move_res = moves.moveChecker(pos[0], pos[1]);
                
                var validFreeMoveFlag = false;
                if(typeof move_res === 'object' && move_res.length !== 0){
                    for(var m in move_res){
                        var moveCell = move_res[m];
                        if(field.calc.getCellDistance(moveCell[0],moveCell[1],pos[0],pos[1])>2){
                            validFreeMoveFlag = true;
                        }
                    }
                
                }
                
                
                if(move_res === true || !validFreeMoveFlag){
                    
                    var colors = {'w':'1','b':'2', '1':'b', '2':'w'};                
                    var color = state.get('move_color') ;
                    state.set('move_color', colors[colors[color]]); 
                    uncheckCeckers();

                    $('.' + field.field_cell_class).removeClass('_red_cell');
                }else{
                
                    // stay moving
                }
                
            });
        };

        return {
            
            regCheckerAction: regCheckerAction
        };

    });