require(["utils/state"],function(state){

    state.set('status','start');
    state.set('g_score',[0,0]);
    state.set('move_color','w');
    state.set('taken_by_1',[]);
    state.set('taken_by_2',[]);
    
});