define(
    ["backbone"],
    function (bbone) {
        var state = bbone.Model.extend({
            
        });

        return new state();
    });